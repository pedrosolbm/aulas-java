package br.com.caelum.capitulo04;

public class FixandoConhecimentoPessoa_4_14_1 {
	String nome;
	int idade;
	
	void fazAniversario() {
		this.idade += 1;
	}
}
