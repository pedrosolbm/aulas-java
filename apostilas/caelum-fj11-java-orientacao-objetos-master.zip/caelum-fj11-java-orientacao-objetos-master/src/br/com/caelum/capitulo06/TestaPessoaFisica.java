package br.com.caelum.capitulo06;

public class TestaPessoaFisica {

	public static void main(String[] args) {
		PessoaFisica pf = new PessoaFisica("93555660268");

	}

}
