package br.com.caelum.capitulo14;

public class ExercicioInteger_14_10_4 {

	public static void main(String[] args) {
		String s1 = "222";

		int i = Integer.parseInt(s1);
		
		System.out.println(i+1);
	}

}
