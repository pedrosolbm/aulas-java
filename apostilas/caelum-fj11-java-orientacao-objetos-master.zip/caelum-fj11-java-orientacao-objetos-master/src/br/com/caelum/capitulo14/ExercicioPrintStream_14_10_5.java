package br.com.caelum.capitulo14;

import java.io.PrintStream;

public class ExercicioPrintStream_14_10_5 {

	public static void main(String[] args) {
		PrintStream saida = System.out;
		saida.println("Ol� Mundo!");
	}

}
