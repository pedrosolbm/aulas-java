package br.com.caelum.capitulo14;

import java.math.BigDecimal;

public class ExercicioBigDecimal_14_10_9 {

	public static void main(String[] args) {
		BigDecimal big = new BigDecimal(16.85214796358);
		
		System.out.println(big);
	}

}
