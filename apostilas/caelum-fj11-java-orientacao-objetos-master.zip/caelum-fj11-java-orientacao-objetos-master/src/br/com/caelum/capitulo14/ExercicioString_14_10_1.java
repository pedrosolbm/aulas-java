package br.com.caelum.capitulo14;

public class ExercicioString_14_10_1 {

	public static void main(String[] args) {
		String s = "fj11";
		s = s.replaceAll("1", "2");
		System.out.println(s);
	}

}
