package br.com.caelum.capitulo14;

public class ExercicioStringBuilder_14_10_15 {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("12345");
		
		System.out.println(sb.reverse());
	}

}
