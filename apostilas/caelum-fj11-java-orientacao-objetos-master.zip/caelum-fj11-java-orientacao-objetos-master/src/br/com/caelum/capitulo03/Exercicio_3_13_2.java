package br.com.caelum.capitulo03;

public class Exercicio_3_13_2 {

	public static void main(String[] args) {
		int soma = 0;
		for(int i = 1; i <= 1000; i++) {
			soma += i;
			System.out.println(soma);
		}
	}

}
