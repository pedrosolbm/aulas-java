package br.com.caelum.capitulo03;

public class Exercicio_3_13_4 {

	public static void main(String[] args) {
		int fatorial = 1;
		for (int n = 1; n <= 10; n++) {
			fatorial *= n;
			System.out.println(fatorial);
		}
	}

}
