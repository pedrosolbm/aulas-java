package br.com.caelum.capitulo02;

public class Exercicio_2_14_2 {

	public static void main(String[] args) {
		System.out.println("Ol�");
		System.out.println("Mundo!");
	}

}
