package br.com.caelum.capitulo02;

public class Exercicio_2_14_1 {

	public static void main(String[] args) {
		System.out.println("Ol� Mundo!");
	}

}
