package br.com.caelum.capitulo02;

public class Exercicio_2_14_3 {

	public static void main(String[] args) {
		System.out.println("Ol�\nMundo!");
	}

}
