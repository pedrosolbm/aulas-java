package br.com.caelum.capitulo16;

public interface Tributavel {
	double calculaTributos();
}
