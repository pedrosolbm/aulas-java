package br.com.caelum.capitulo11;

public interface Tributavel {
	double calculaTributos();
}
