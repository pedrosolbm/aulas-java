package br.com.caelum.capitulo10;

public interface AreaCalculavel {
	double CalculaArea();
}
