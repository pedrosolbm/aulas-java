package br.com.caelum.capitulo10;

public class Teste {
	public static void main(String[] args) {
		AreaCalculavel a = new Retangulo(2, 2);
		System.out.println(a.CalculaArea());
	}
}
