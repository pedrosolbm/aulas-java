package br.com.caelum.capitulo10;

public interface Tributavel {
	double calculaTributos();
}
