package com.apirest.apireststarwar.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.apirest.apireststarwar.document.Planetas;

public interface PlanetaRepository extends MongoRepository<Planetas, String> {

}
