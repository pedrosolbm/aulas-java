package com.apirest.apireststarwar.servicesImp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.apirest.apireststarwar.document.Planetas;
import com.apirest.apireststarwar.repository.PlanetaRepository;
import com.apirest.apireststarwar.services.PlanetaService;


@Service
public class PlanetaServiceImp implements PlanetaService {

	@Autowired
	private PlanetaRepository planetaRepository; 
	
	
	private static final String SWAPI_URL="https://swapi.co/api/planets/?search=";
	
	
	@Override
	public List<Planetas> listaTodos() {
		// TODO Auto-generated method stub
		return this.planetaRepository.findAll();
	}
/*
	@Override
	public Object listarPorId(String id) {
		// TODO Auto-generated method stub
		return this.clienteRepository.findById(id);
	}
*/
	@Override
	public Planetas cadastrar(Planetas cliente) {
		// TODO Auto-generated method stub
		return planetaRepository.save(cliente);
	}

	@Override
	public Planetas atualizar(Planetas cliente) {
		// TODO Auto-generated method stub
		return planetaRepository.save(cliente); 
	}

	@Override
	public void remover(String id) {
		
		this.planetaRepository.deleteById(id);
		// TODO Auto-generated method stub

	}
}
