// atributos que serão utilizados ao longo da criação de cursos da aplicação
export interface Curso {
    id: number;
    nome: string;
  }